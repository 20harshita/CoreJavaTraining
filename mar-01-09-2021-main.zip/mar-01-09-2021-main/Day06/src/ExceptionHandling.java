
public class ExceptionHandling {

	public static void main(String[] args) {
		int[] arr = { 10, 20 };
		try {
			arr[4] = 100; // Creates an object of Exception; populates the object with the error information
		} catch (Exception e) {
			//System.out.println("Error occcured: " + e.getMessage());
		}
		
		try {
			doSomething();	
		}
		catch(Exception ex) {
			System.out.println("Error: " + ex.getMessage());
		}
		
		System.out.println("End of main");

	}
	
	static void doSomething() {
		int x = 100;
		int y = 0;
		x = x / y;
	}

}
