import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class CheckedAndUnCheckedExceptions {

	public static void main(String[] args) throws IOException, Exception {
		mathOps();
		fileOperations();
		funnyOps();
	}
	
	static void fileOperations() throws IOException {
		String fileName = "./training.txt";
		Files.createFile(Paths.get(fileName));	
	}
	
	static void funnyOps() throws Exception {
		int i = 10;
		if(i % 2 == 0) {
			System.out.println("Even number");
		} else if(i % 2 == 1) {
			System.out.println("Odd number");
		} else {
			//System.out.println("Dunno what number it is");
			throw new Exception("Dunno what number it is");
		}
		
	}
	
	
	static void mathOps() {
		int i = 10;
		int j = 0;
		int result = i / j;	//Unchecked exceptions need not have code written to handle
	}
	
	static void fileOps() {
		String fileName = "./training.txt";
		try {
			Files.createFile(Paths.get(fileName));	
		}
		catch(IOException ex) { //IOExceptions, DB exceptions are checked exceptions;
			System.out.println(ex);
		}
		
	}

}
