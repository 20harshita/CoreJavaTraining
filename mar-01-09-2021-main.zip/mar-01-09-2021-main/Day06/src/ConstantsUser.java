public class ConstantsUser {

	public static void main(String[] args) {
		System.out.println(Month.JAN);
		System.out.println(Month.FEB);
		
		System.out.println();
		
		System.out.println(Months.JAN);
		System.out.println(Months.FEB);
		
		System.out.println(Months.JAN.info());
		
		for (Months item : Months.values()) {
			System.out.println(item);
		}
		System.out.println(Months.JAN.getClass().getName());
		
	}

}
