
public class CustomExceptionsExample {

	public static void main(String[] args) /*throws SwitchAlreadyOnException, SwitchAlreadyOffException */{
		Switch sw = new Switch();
		try {
			sw.turnOn();
			sw.turnOff();
			sw.turnOff();
		} catch (SwitchAlreadyOnException | SwitchAlreadyOffException e) {
			e.printStackTrace();
		}
	}

}

class Switch {
	private boolean position;
	
	public void turnOn() throws SwitchAlreadyOnException {
		if(position) {
			throw new SwitchAlreadyOnException();
		}
		position = true;
	}
	
	public void turnOff() throws SwitchAlreadyOffException {
		if(!position) {
			throw new SwitchAlreadyOffException();
		}
		position = false;
	}
}
class SwitchAlreadyOnException extends Exception {}
class SwitchAlreadyOffException extends Exception {}
