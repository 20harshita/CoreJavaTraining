public enum Months {
	JAN, FEB, MAR, APR;
	
	String info() {
		return "hello";
	}
}
