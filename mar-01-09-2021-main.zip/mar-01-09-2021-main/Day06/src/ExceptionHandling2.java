
public class ExceptionHandling2 {

	public static void main(String[] args) {
		try {
			System.out.println("Inside try");
			//int i = 10 / 0;
			//Open a connection to database
			//execute the queries; [Say, an error occurs here]
			
		}
		catch(ArithmeticException | ArrayIndexOutOfBoundsException ex) {
			System.out.println("Inside catch");
		}
		catch(NumberFormatException | NullPointerException ex) {
			System.out.println("Inside catch");
		}
//		catch(ArithmeticException ex) {
//			System.out.println("Inside catch");
//		}
//		catch(ArrayIndexOutOfBoundsException ex) {
//			System.out.println("Inside catch");
//		}
//		catch(Exception ex) {
//			System.out.println("Inside catch");
//		}
		finally {
			System.out.println("Inside finally");
			//close the connection to database
		}

	}

}
