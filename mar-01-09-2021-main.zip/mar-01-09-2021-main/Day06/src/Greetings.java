// Functional interface
@FunctionalInterface
public interface Greetings {
	void hello(String name);
//	void bye();
}

//Marker interfaces are those with NO abstract method
