import java.util.Arrays;
import java.util.List;

public class StreamsExample {

	public static void main(String[] args) {
		List<String> cities = Arrays.asList("Chennai", "Pune", "Bangalore", "Cochin", "Bhopal");
		
		//LISP
		//Ruby
		
		
		// Display the cities that start with letter B
		//Imperative style of coding
		//You write code to say what to do and also how to do
		/*
		for (int i = 0; i < cities.size(); i++) {
			String city = cities.get(i);
			if(city.startsWith("B")) {
				System.out.println(city);
			}
		}
		*/
		
		//Declarative style of coding
		//You only say what to do
		cities
			.stream()
			.parallel()
			.filter(item -> item.startsWith("B"))
			.forEach(System.out::println);
		
		// Check if Pune is present in this collection
		
		String city = cities
			.stream()
			.filter(item -> item.equals("Pune"))
			.findAny()
			.orElse(null);
		if(city != null) {
			System.out.println("Pune is found in the collection");
		}
		else {
			System.out.println("Pune is not found in the collection");
		}
		
		
		
		
		/*
		boolean found = false;
		for (int i = 0; i < cities.size(); i++) {
			String city = cities.get(i);
			if(city.equals("Pune")) {
				found = true;
			}
		}
		if(found) {
			System.out.println("Pune is present in the collection");
		}
		else {
			System.out.println("Pune is not present in the collection");
		}*/
	}

}
