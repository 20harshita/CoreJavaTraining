import java.util.ArrayList;

public class StaticExample {

	public static void main(String[] args) {
//		Registrar registrar = new  Registrar();
//		
//		Company tcs = new Company("TCS");
//		registrar.register("TCS");
//		
//		Company intuit = new Company("Intuit");
//		registrar.register("Intuit");
		
		Company intuit = new Company("Intuit");
		Company wipro = new Company("Wipro");
		
	}

}

class Company {
	private String name;
	private long employeeCount;
	//private Registrar registrar = new Registrar();
	
	public Company(String name) {
		this.name = name;
		//registrar.register(name);
		Registrar.register(name);
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getEmployeeCount() {
		return employeeCount;
	}
	public void setEmployeeCount(long employeeCount) {
		this.employeeCount = employeeCount;
	}
	
}

class Registrar {
	private static ArrayList<String> ledger = new ArrayList<String>();
	
	public static void register(String name) {
		System.out.println("Registering " + name);
		ledger.add(name);
	}
	
}