public interface Aquatic {
	abstract void swim();
	default public void floatOnWater() {
		System.out.println("Floating");
	}
}
