public class Frog implements Terrestrial, Aquatic {
	public void walk() {
		
	}
	public void swim() {
		
	}
	
	public void floatOnWater() {
		System.out.println("Floating peacefully");
	}
}
