public class Cat extends Animal {
	public Cat() {
		super(2);
	}
	
	public void makeNoise() {
		System.out.println("meow meow");
	}
}
