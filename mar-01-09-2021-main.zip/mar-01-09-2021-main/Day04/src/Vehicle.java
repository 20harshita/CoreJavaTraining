abstract public class Vehicle {
	public void start() {
		
	}
}
