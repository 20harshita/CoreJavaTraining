
public class FinalKeywordExample {

	public static void main(String[] args) {
		final String city = "Chennai";
		
	}

}

final class Employee {}
//class Manager extends Employee {}

class MyBook {
	public final void read() {}	
}
class SciFiBook extends MyBook {
	//public void read() {}
}