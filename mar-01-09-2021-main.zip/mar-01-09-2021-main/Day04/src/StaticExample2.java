
public class StaticExample2 {

	public static void main(String[] args) {
		Integer iObj = 12;
		//System.out.println(StoryBook.bookCount);
		StoryBook sb = new StoryBook();
		
		System.out.println(Book.bookCount);
		
		StoryBook.printDetails();
		
//		
//		Book b1 = new Book("outliers");
//		Book b2 = new Book("Factfulness");
//		System.out.println(Book.bookCount);
//		System.out.println(b1.bookCount); // NOT RECOMMENDED
		
		doSomething();
		//doSomethingElse(); //cannot call directly
		
		StaticExample2 obj = new StaticExample2();
		obj.doSomethingElse();
	}
	
	void doSomethingElse() {}
	
	static void doSomething() {
		
	}

}

class StoryBook {
	public static int bookCount;	
	private String name;
	
	static {
		System.out.println("This is a static block for StoryBook");
		bookCount = 1000;
	}
	
	public static void printDetails() {
		//from a static method you CANNOT directly call non-static members
		
		// System.out.println(name); 
		//info();
	}
	
	public void info() {
		printDetails();
		System.out.println(bookCount);
	}
	
	
	
}

class Book {
	private String title;	// member variable
	public static int bookCount;	// class variable
	
	// static initializer block
	static {
		System.out.println("This is a static block for Book");
		bookCount = 100;
		//title = "ABC"; // ERROR
	}
	
	public Book(String title) {
		this.title = title;
		bookCount++;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
}
