// abstract classes cannot be instantiated
abstract public class Animal {
	private int eyes;
	public Animal(int eyes) {
		this.eyes = eyes;
	}
	public void eat() {
		System.out.println("Eating");
	}
	
	abstract public void makeNoise(); 
	
}
