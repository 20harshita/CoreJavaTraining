package com.intuit.lab08;

public interface Alarm {
	void activate();
	void deactivate();
}
