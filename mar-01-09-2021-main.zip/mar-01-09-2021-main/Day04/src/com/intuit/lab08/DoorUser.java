package com.intuit.lab08;

public class DoorUser {

	public static void main(String[] args) {
		Door door = new Door();
		SoundAlarm soundAlarm = new SoundAlarm();
		door.setAlarm(soundAlarm);
		door.open();
		door.close();
		System.out.println("*****Changing the alarm type");
		VisualAlarm visualAlarm = new VisualAlarm();
		door.setAlarm(visualAlarm);
		door.open();
		door.close();
		System.out.println("=====Changing the alarm type");
		SmsAlarm smsAlarm = new SmsAlarm();
		door.setAlarm(smsAlarm);
		door.open();
		door.close();
	}

}
