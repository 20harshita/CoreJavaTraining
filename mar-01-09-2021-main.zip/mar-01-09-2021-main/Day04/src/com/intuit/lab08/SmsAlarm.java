package com.intuit.lab08;

public class SmsAlarm implements Alarm {

	public void activate() {
		System.out.println("Send message - Door opened");
	}

	public void deactivate() {
		System.out.println("Send message - Door closed");
	}

}
