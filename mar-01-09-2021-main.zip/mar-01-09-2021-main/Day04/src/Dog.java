public class Dog extends Animal {
	public Dog() {
		super(2);
	}
	
	public void makeNoise() {
		System.out.println("bow bow");
	}
}
