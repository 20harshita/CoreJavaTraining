
public class StaticInheritance {
	public static void main(String[] args) {
		Engineer sam = new SWEngineer();
		sam.work(); // static methods ARE NOT overridden
		
		//static methods have an impact on extensibility
		//creating classes with a lot of static methods thinking that it saves memory is a myth
		//it's a flawed design
		//your code will become completely non-extensible
		//USE static methods sparingly
	}
}


class Engineer {
	 void work() {
		System.out.println("Engineer working");
	}
}

class SWEngineer extends Engineer {
	 void work() {
		System.out.println("SW Engineer working");
	}
}