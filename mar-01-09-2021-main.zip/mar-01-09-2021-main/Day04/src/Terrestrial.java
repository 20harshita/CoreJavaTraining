public interface Terrestrial {
	int count = 10; //implicitly public and final
	abstract void walk();
	default public void runFast() {
		System.out.println("Running");
	}
	private static void doSomethingSilly() {
		
	}
	static void doSomething() {}
}
