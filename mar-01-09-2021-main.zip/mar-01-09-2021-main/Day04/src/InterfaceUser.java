
public class InterfaceUser {

	public static void main(String[] args) {
		
		final double pi = 3.14;
		
		// Terrestrial t = new Terrestrial();
		Frog f = new Frog();
		f.swim();
		f.walk();
		f.runFast();
		f.floatOnWater();
		
		Terrestrial.doSomething();
		System.out.println(Terrestrial.count);
		//Terrestrial.count = 100;
		
		Terrestrial t = new Frog();
		t.walk();
		//t.swim();
		
		//Terrestrial dog = new Dog();
		
		
		Aquatic aq = new Frog();
		aq.swim();
	}

}
