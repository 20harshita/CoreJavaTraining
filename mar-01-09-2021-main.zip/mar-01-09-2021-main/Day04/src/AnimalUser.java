public class AnimalUser {

	public static void main(String[] args) {
		// Conceptually meaningless
		// Animal animal = new Animal();
		
		Animal snoopy = new Dog();
		Animal rover = new Cat();
		train(snoopy);
		train(rover);
	}
	
	static void train(Animal animal) {
		animal.eat();
		animal.makeNoise();
	}

}
