* Create a package __com.intuit.lab08__

* Design a __door__ that will be monitored by an __alarm__
* When you open the door the alarm gets __activated__
* When you close the door the alarm gets __deactivated__
* You have two types of alarm; a __sound alarm__ and a __visual alarm__
* sound alarm raises sound when activated
* visual alarm streams the door and its area and shows up in a monitor
* In future you may have more types of alarms introduced
* Design your door in such a way that any type of alarm can be fit into it without changing its design

* __Note:__ Use sysout statements in activate and deactivate operations for simplicity