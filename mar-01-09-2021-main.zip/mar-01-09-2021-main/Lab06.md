* Create a class called __Account__ in a package __com.lab06__ that does the following. Don't worry about packages concept. Just use the IDE's facilities to create a package.
* It has a balance that needs to be initialized with a value greater than 10000
* Methods to deposit, withdraw. If there isn't sufficient balance don't allow withdraw.
* You can withdraw only 3 times. After that you will be charged 0.5% of the amount as Fees.

* Create an object of __Account(20000)__ from main() in __AccountUser.java__ and call deposit twice and withdraw 5-6 times. Print the Balance

* Implement a method __printStatement__ that prints the list of transactions performed. 
* This method will display the account number, amount, type of transaction(deposit or withdraw) and the time.
* You can create an instance of __java.util.ArrayList__ and use methods like __size(), get()__ for storing the transactions.

* Follow the basic design constructs in Java language in this lab.