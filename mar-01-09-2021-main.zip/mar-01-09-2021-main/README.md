# Core Java

```java
  course(instructor -> 
      instructor.name("Prabhu Sunderaraman")
            .email("prabhu.bits@gmail.com")
            .blog("http://healthycoder.in")
            .books("Spring 3.0 Black Book", "Practical Ext JS 4")
    );
```

