//POJO notation
//Java Beans
public class Country {
	private String name;
	private String capital;
	private long population;
	
	
	// constructor overloading
	
	public Country(Country another) {
		this.name = another.name;
		this.capital = another.capital;
		this.population = another.population;
	}
	
	public Country(String name, String capital) {
		this.name = name;
		this.capital = capital;
	}
	
	public Country(String name, long population) {
		this.name = name;
		this.population = population;
	}
	
	public Country(String name) {
		this.name = name;
	}
	public Country(String name, String capital, long population) {
		this.name = name;
		this.capital = capital;
		this.population = population;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCapital() {
		return capital;
	}
	public void setCapital(String capital) {
		this.capital = capital;
	}
	public long getPopulation() {
		return population;
	}
	public void setPopulation(long population) {
		this.population = population;
	}
	
}
