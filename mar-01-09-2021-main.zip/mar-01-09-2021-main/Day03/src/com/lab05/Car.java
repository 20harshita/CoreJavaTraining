package com.lab05;

public class Car {
	String model;
	String color;
	Engine engine;
	
	Car(String theModel, String theColor, Engine theEngine) {
		model = theModel;
		color = theColor;
		engine = theEngine;
	}
	
//	Car(String theModel, String theColor, long enginePower) {
//		model = theModel;
//		color = theColor;
//		engine = new Engine(enginePower);
//	}
	
//	Car(String theModel, String theColor) {
//		model = theModel;
//		color = theColor;
//	}
}
