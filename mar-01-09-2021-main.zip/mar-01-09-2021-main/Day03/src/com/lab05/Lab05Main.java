package com.lab05;

public class Lab05Main {

	public static void main(String[] args) {
		Person sam = new Person("Sam");
		
//		Car bmw = new Car("BMW", "Black", 2000);
//		bmw.engine = new Engine(2000);
//		
//		Car santro = new Car("Santro", "Yellow", 1000);
//		santro.engine = new Engine(1000);
		
		Car bmw = new Car("BMW", "Black", new Engine(2000));
		Car santro = new Car("Santro", "Yellow", new Engine(1000));
		
		sam.cars = new Car[] { bmw, santro };
		
		Person ram = new Person("Ram");
		ram.cars = new Car[] {};

		sam.friend = ram;
		ram.friend = sam;
		
		System.out.println(ram.friend.cars[0].engine.power);
		
	}

}
