package com.lab05;

public class Person {
	String name;
	Car[] cars;
	Person friend;
	
	Person(String theName) {
		name = theName;
	}
}
