package com.lab05;

public class Engine {
	long power;
	
	Engine(long thePower) {
		power = thePower;
	}
}
