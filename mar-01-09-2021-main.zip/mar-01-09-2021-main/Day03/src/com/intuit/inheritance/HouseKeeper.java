package com.intuit.inheritance;

import java.time.LocalDateTime;

public class HouseKeeper extends Employee {
	public HouseKeeper(String name, double salary) {
		super(name, salary);
	}
	
	public void printLoggingDetails() {
		System.out.println("Housekeeper(" + getName() +  ") logging at " + LocalDateTime.now());
	}
}
