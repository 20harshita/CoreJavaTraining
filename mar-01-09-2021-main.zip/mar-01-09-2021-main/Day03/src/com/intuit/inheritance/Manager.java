package com.intuit.inheritance;

import java.time.LocalDateTime;

//Derived class
//Sub class
//Child class
public class Manager extends Employee {
	private int level;

	// Derived class constructor SHOULD have a call to the base class constructor in its first line
	public Manager(String name, double salary, int level) {
		super(name, salary);
		this.level = level;
	}
	
	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}
	//Method overriding (same signature)
	public void work() {
		System.out.println("Manager: " + super.getName() + " is working");
	}
	
	public void printLoggingDetails() {
		System.out.println("Manager(" + getName() +  ") logging at " + LocalDateTime.now());
	}
	
}
