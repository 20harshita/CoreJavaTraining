package com.intuit.inheritance;

public class Main {

	public static void main(String[] args) {
//		Employee e1 = new Employee("Sam", 10000);
////		e1.setName("Sam");
////		e1.setSalary(10000);
//		e1.work();
//		e1.printLoggingDetails();
//		
//		Manager m1 = new Manager("John", 200000, 5);
////		m1.setName("John");
////		m1.setSalary(200000);
////		m1.setLevel(5);
//		m1.work();
//		m1.printLoggingDetails();
		
		Employee emp = new Employee("Sam", 2000);
//		Manager m = new Manager("Joe", 20000, 4);
//		HouseKeeper hk = new HouseKeeper("Mary", 500);
		
		Employee m = new Manager("Joe", 20000, 4);
		Employee hk = new HouseKeeper("Mary", 500);
		
		//Manager m2 = new Employee("John", 100);
		
		securityCheck(emp);
		securityCheck(m);
		securityCheck(hk);
		
		
//		securityCheckForEmployee(emp);
//		securityCheckForManager(m);
//		securityCheckForHouseKeeper(hk);
	}
	
	// Polymorphism = Inheritance + method overriding
	// single interface but different responses based on the type of the object you pass
	static void securityCheck(Employee emp) {
		emp.printLoggingDetails();
	}
	
	
	
//	static void securityCheckForEmployee(Employee emp) {
//		emp.printLoggingDetails();
//	}
//	
//	static void securityCheckForManager(Manager m) {
//		m.printLoggingDetails();
//	}
//	
//	static void securityCheckForHouseKeeper(HouseKeeper h) {
//		h.printLoggingDetails();
//	}
}
