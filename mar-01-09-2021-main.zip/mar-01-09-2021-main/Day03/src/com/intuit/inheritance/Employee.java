package com.intuit.inheritance;

import java.time.LocalDateTime;

//Base class
//Super class
//Parent class
public class Employee {
	private String name;
	private double salary;
	
	public Employee(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public void work() {
		System.out.println("Employee: " + this.name + " is  working");
	}
	
	public void printLoggingDetails() {
		System.out.println("Employee(" + this.name +  ") logging at " + LocalDateTime.now());
	}
	
	
}
