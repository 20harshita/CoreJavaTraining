package com.lab06;

public class CurrentAccount extends Account{

	private String name;
	
	public CurrentAccount(double initialBalance, String name) {
		super(initialBalance);
		this.name = name;
	}
	
	public int getWithdrawLimit() {
		return 10;
	}
	
	public void withdraw(double amount) {
		if(amount < 100000) {
			super.withdraw(amount);
		}
	}
	
}
