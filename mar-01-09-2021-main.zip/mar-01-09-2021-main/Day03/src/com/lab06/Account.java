package com.lab06;

import java.util.ArrayList;

public class Account {

	private double balance;
	private int withdrawCount;
	private ArrayList<Transaction> transactions;

	public Account(double initialBalance) {
		if(initialBalance > 10000) {
			balance = initialBalance;
			transactions = new ArrayList<>();			
		}
		else {
			throw new RuntimeException("Balance should be gt 10000");
		}
	}

	public double getBalance() {
		return balance;
	}
	

	public int getWithdrawLimit() {
		return 3;
	}


	private void addTransaction(String type, double amount) {
		Transaction txn = new Transaction(type, amount);
		transactions.add(txn);
	}

	public void deposit(double amount) {
		balance += amount;
		addTransaction("Deposit", amount);
	}

	public void withdraw(double amount) {
		withdrawCount++;
		balance -= amount;
		addTransaction("Withdraw", amount);

		if(withdrawCount > getWithdrawLimit()) {
			double fee = amount * 0.005;
			balance -= fee;
			addTransaction("Withdraw fee", fee);
		}
	}

	public void printStatement() {
		for (Transaction txn : transactions) {
			System.out.println(txn.getType() + ", " + "Rs." + txn.getAmount() + " on " + txn.getDate().toString());
		}
	}
}
