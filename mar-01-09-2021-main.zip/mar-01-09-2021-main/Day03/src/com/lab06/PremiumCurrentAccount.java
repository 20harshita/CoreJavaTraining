package com.lab06;

public class PremiumCurrentAccount extends Account {
	private String name;
	
	public PremiumCurrentAccount(double initialBalance, String name) {
		super(initialBalance);
		this.name = name;
	}
	
	public int getWithdrawLimit() {
		return 100;
	}
	
	public void withdraw(double amount) {
		if(amount < 1000000) {
			super.withdraw(amount);
		}
	}
}
