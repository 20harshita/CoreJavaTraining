package com.lab06;

import java.util.Iterator;

public class AccountUser {

	public static void main(String[] args) {
		Account account = new Account(20000);
		account.deposit(10000);
		account.deposit(10000);
		account.withdraw(100);
		account.withdraw(100);
		account.withdraw(100);
		account.withdraw(100);
		account.withdraw(100);
		account.withdraw(100);
		System.out.println("Balance: " + account.getBalance());
		System.out.println("--------Statement----------");
		account.printStatement();
		
		System.out.println();
		
		System.out.println("***Current Account***");
		CurrentAccount curAcc = new CurrentAccount(100000, "Training");
		curAcc.deposit(1000);
		curAcc.deposit(1000);
		for (int i = 0; i < 15; i++) {
			curAcc.withdraw(10);
		}
		curAcc.printStatement();
		System.out.println("Current Account Balance: " + curAcc.getBalance());
		
		System.out.println();
		
		System.out.println("***Premium Current Account***");
		PremiumCurrentAccount premAcc = new PremiumCurrentAccount(1000000, "Training");
		premAcc.deposit(10000);
		premAcc.deposit(10000);
		for (int i = 0; i < 115; i++) {
			premAcc.withdraw(10);
		}
		premAcc.printStatement();
		System.out.println("Premium Current Account Balance: " + premAcc.getBalance() );
		
		System.out.println();
		
//		Account account2 = new Account(1000);
//		System.out.println(account2.getBalance());
		
	}

}
