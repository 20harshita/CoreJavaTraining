public class Employee {
	
	//Method overloading
	public void work() {
		System.out.println("Working 8 hours/day");
	}
	
	public void work(int hours) {
		System.out.println("Working " + hours + " hours/day");
	}
	
	public void work(int hours, int minutes) {
		System.out.println("Working " + hours + " hours and " + minutes + " mins/day");
	}
}
