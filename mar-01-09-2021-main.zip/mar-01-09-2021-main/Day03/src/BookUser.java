
public class BookUser {

	public static void main(String[] args) {
		Book b1 = new Book("Elegant Puzzle", 20.34);
		b1.buy("Amazon");
		//b1.price = -100;
		b1.setPrice(-100);
		//System.out.println(b1.title + " " + b1.price);
		System.out.println(b1.getTitle() + " " + b1.getPrice());
	}

}
