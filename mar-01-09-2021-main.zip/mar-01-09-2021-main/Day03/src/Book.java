//Make all the member variables private; and define public getter/setter functions (or properties)
//Make all the member functions public

public class Book {
	private String title;
	private double price;
	
	public String getTitle() {
		return title;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double value) {
		if(value > 0) {
			price = value;
		}
		else {
			System.out.println("Invalid value for price: " + value);
		}
			
	}
	

	public Book(String theTitle, double thePrice) {
		title = theTitle;
		price = thePrice;
	}
	
	public void buy(String store) {
		System.out.println("Buying " + title + " from " + store);
	}
}
