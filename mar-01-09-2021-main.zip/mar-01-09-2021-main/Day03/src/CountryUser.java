
public class CountryUser {

	public static void main(String[] args) {
		Country india = new Country("India", "ND", 876896986);
		System.out.println(india.getName());
		System.out.println(india.getCapital());
		System.out.println(india.getPopulation());
		
		Country us = new Country("USA");
		Country france = new Country("France", "Paris");
		Country greenland = new Country("Greenland", 100000);
		//Country sl = new Country();
		
		Country duplicate = new Country(india);
		
		Employee emp1 = new Employee();
		emp1.work();
		emp1.work(12);
		emp1.work(8, 35);
	}

}
