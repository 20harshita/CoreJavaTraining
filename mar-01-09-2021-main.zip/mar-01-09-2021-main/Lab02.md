* Create Lab02.java with a main method
* Implement the following functions
* __calculateSquare__ takes an array of numbers, squares the values and returns void
* __increment__ takes an array of numbers, and increments each by 1 and does not return anything
* __doubleIt__ takes an array of numbers and doubles each and returns void

* Print the result finally

* Here's the sample output

```
Enter number I
3
Enter number II
5
Enter number III
10

***squaring (3, 5, 10)
***incrementing  (9, 25, 100)
***doubling (10, 26, 101)

Output of [3, 5, 10] ->  20, 52, 202  
```