* Reuse the Account.java that you implemented in Lab06.
* Create CurrentAccount class
* CurrentAccount has a name
* CurrentAccount allows 10 withdrawals
* Limit of withdraw amount at any point of time is 1 Lakh only
* Create a Premium Current account that allows 100 withdrawals and withdraw limit is 10L

* Create some Current Account and Premium Current Account objects and use the deposit and withdraw methods. Print statement to check the transactions and display the balance