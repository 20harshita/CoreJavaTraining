
public class StringBufferOrBuilder {

	public static void main(String[] args) {
		
		//Thread-safe
		StringBuffer sb = new StringBuffer("");
		sb.append("Hello");
		sb.append(" ");
		sb.append("there");
		sb.append("!");
		System.out.println(sb.toString());
		
		//Not thread-safe; faster than StringBuffer
		StringBuilder sbuilder = new StringBuilder("");
		sbuilder.append("Hello");
		sbuilder.append(" ");
		sbuilder.append("there");
		sbuilder.append("!");
		System.out.println(sbuilder.toString());

	}

}
