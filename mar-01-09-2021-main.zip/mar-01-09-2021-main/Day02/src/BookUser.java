
public class BookUser {

	public static void main(String[] args) {
		Book b1 = new Book("Outliers", 24.56);
		b1.author = new Author("Malcolm");
		System.out.println(b1.title + ": " + b1.author.name);
		
		Book b2 = new Book("Outliers - II", 45.56);
		b2.author = b1.author;
		System.out.println(b2.title + ": " + b2.author.name);
	}

}
