import java.util.ArrayList;

public class AutoBoxing {

	public static void main(String[] args) {
		// Convert primitive type to reference type 
		
		int num = 10;
		Integer numObj = num;

		double pi = 3.14;
		Double piObj = pi;
		
		// Integer, Double, Float, Long, Character, Boolean are called Wrapper classes
		
		boolean b = true;
		Boolean bObj = b;
		
		
		
		// Convert reference type to primitive type

		Integer evenObj = 100;
		int even = evenObj;
		
		// Example of storing a collection of objects
		
		ArrayList<Integer> numbers = new ArrayList<>();
		numbers.add(1);
		numbers.add(2);
		numbers.add(3);

		//ArrayList<int> numbers2 = new ArrayList<>();
	}

}
