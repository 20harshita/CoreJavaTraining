import java.util.Scanner;

public class GameUser {

	public static void main(String[] args) {
		GuessingGame game = new GuessingGame();
		Scanner sc = new Scanner(System.in);
		int guess = -1;
		System.out.println("Welcome to the guessing game. Enter a number between 1 and 100");
		
		while(!game.gameOver) {
			guess = sc.nextInt();
			game.play(guess);
			System.out.println(game.message);
		}
		sc.close();
	}

}
