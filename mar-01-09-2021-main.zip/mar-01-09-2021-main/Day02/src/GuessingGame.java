public class GuessingGame {
	int target;
	int attempts;
	String message;
	boolean gameOver;
	
	GuessingGame() {
		target = (int)(Math.random() * 100);
		attempts = 0;
		gameOver = false;
	}
	
	void play(int guess) {
		attempts++;
		if(guess > target) {
			message = "Aim Lower";
		}
		else if(guess < target) {
			message = "Aim Higher";
		}
		else {
			message = "You 've got it in " + attempts + " attempts";
			gameOver = true;
		}
	}
}
