//New reference data type
public class Person {
	// have characteristics or properties defined as variables
	
	// member variables or instance variables
	String name;
	int age;
	String gender;
	
	//way to initialize members
	//a special function to do that 
	//constructor is a special function that has the same name as the class and no return value
	Person(String theName, int theAge, String theGender) {
		name = theName;
		age = theAge;
		gender = theGender;
	}
	
	
	// behaviours defined as methods
	// instance methods or member functions
	void eat() {
		
	}
	
	void work(int hours) {
		System.out.println(name + " is working for " + hours + " hours");
	}
	
}
