public class Book {
	String title;
	double price;
	Author author;
	
	Book(String theTitle, double thePrice) {
		title = theTitle;
		price = thePrice;
	}
}
