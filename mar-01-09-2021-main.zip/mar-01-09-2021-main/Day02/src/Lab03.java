public class Lab03 {
	static String input1 = "+5 -1 +9 +5 -7 +5 -3 +2 -4 +6 +8";
	static String input2 = "p5 m1 p9 p5 m7 p5 m3 p2 m4 p6 p8";
	
	public static void main(String[] args) {
		System.out.println(computeResultForInput1());
		System.out.println(computeResultForInput2());
	}

	private static int computeResultForInput2() {
		String[] items = input2.split(" ");
		int result = 0;
		for (String item : items) {
			char operator = item.charAt(0);
			int num = Integer.parseInt(item.substring(1));
			result += operator == 'p' ? num : -num;
		}
		return result;
	}

	private static int computeResultForInput1() {
		String[] items = input1.split(" ");
		int result = 0;
		for (String item : items) {
			int number = Integer.parseInt(item);
			result += number;
		}
		return result;
	}

}
