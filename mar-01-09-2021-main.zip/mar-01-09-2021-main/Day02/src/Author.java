public class Author {
	String name;

	Author(String theName) {
		name = theName;
	}
}
