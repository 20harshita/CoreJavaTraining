public class PersonUser {
	public static void main(String[] args) {
		// p1 is an object of Person class
		// p1 is an instance of Person
		// Person is instantiated to create an object p1
		// p1 is a reference to a Person class Object
//		Person p1 = new Person();
//		System.out.println(p1);
//		Person p2 = new Person();
//		System.out.println(p2);
//		
//		Person p3 = p1;
//		System.out.println(p3);
//		
//		p2 = null; // The object becomes eligible to be garbage collected
//		System.gc(); // Not recommended
//		System.out.println(p2);
		
	}
}
