
public class PersonUser2 {

	public static void main(String[] args) {
		Person p1 = new Person("Ram", 34, "Male");
		System.out.println(p1.name + ", " + p1.age + ", " + p1.gender);
		p1.eat();
		p1.work(2);
		
		Person p2 = new Person("Mary", 45, "Female");
//		p2.name = "Sam";
//		p2.age = 10;
//		p2.gender = "male";
		System.out.println(p2.name + ", " + p2.age + ", " + p2.gender);
		p2.work(8);
	}

}
