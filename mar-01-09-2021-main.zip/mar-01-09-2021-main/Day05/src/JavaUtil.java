import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class JavaUtil {

	public static void main(String[] args) {
		List<Integer> numbers = new ArrayList<>();
		numbers.add(100);
		numbers.add(200);
		numbers.add(300);
		numbers.add(300);
		numbers.add(100);
		
		for (Integer num : numbers) {
			System.out.println(num);
		} 
		System.out.println(numbers.size());

		System.out.println();
		
		Set<Integer> numbersSet3 = new LinkedHashSet<>();
		Set<Integer> numbersSet2 = new TreeSet<>();
		Set<Integer> numbersSet = new HashSet<>();
		numbersSet.add(100);
		numbersSet.add(200);
		numbersSet.add(300);
		numbersSet.add(300);
		numbersSet.add(100);
		
		for (Integer num : numbersSet) {
			System.out.println(num);
		} 
		System.out.println(numbersSet.size());

		Map<Integer, String> romanNumbers = new HashMap<>();
		romanNumbers.put(1, "I");
		romanNumbers.put(2, "II");
		romanNumbers.put(3, "III");
		
		Set<Integer> keys = romanNumbers.keySet();
		for (Integer key : keys) {
			System.out.println(key + ": " + romanNumbers.get(key));
		}
		
		
		
		
	}

}
