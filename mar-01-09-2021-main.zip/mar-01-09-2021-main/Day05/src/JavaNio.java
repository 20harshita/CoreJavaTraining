import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;

public class JavaNio {

	public static void main(String[] args) throws Exception {
		String contents = "Hello there!";
		
		//Files, Paths
		String fileName = "./training.txt";
		
		//Files.write(Paths.get(fileName), contents.getBytes());
		
		byte[] content = Files.readAllBytes(Paths.get(fileName));
		System.out.println(new String(content));
		
		System.out.println("Done");
		
		URI uri = new URI("https://intuit.com");
	}

}
