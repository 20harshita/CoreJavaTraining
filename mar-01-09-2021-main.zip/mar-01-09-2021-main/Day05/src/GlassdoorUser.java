import com.intuit.training.Employee;
import com.intuit.training.Manager;

public class GlassdoorUser {

	public static void main(String[] args) {
		Manager m = new Manager();
		//System.out.println(m.name + ", " + m.salary);
	}

}

class Director extends Employee {
	public void printInfo() {
		System.out.println(name + ", " + salary);
	}
}
