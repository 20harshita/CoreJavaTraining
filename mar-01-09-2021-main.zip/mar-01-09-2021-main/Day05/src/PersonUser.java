//import com.intuit.training.*;
import com.intuit.training.MessageConstants;
import com.intuit.training.Person;
import static com.intuit.training.MessageConstants.*;
//import static com.intuit.training.FamilyUser.*;

public class PersonUser {

	public static void main(String[] args) {
		Person person = new Person();
		System.out.println(person.name);
		//System.out.println(person.age);
		
		
//		System.out.println(MessageConstants.header);
//		System.out.println(MessageConstants.footer);
//		System.out.println(MessageConstants.logo);
		
		System.out.println(header);
		System.out.println(footer);
		System.out.println(logo);
	}

}
