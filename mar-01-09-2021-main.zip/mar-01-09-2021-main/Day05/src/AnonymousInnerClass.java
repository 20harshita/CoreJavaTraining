public class AnonymousInnerClass {

	public static void main(String[] args) {
		Greetings greetings = new GreetingsImpl();
		greetings.hello("Sam");
		
		//Greetings greetingsModern = new Greetings(); WRONG
		
		//Anonymous inner class
		Greetings greetingsModern = new Greetings() {
			public void hello(String name) {
				System.out.println("Hey " + name);
			}
		};
		greetingsModern.hello("Ram");
		
		Greetings greetingsCool = new Greetings() {
			public void hello(String name) {
				System.out.println("Wasssup " + name);
			}
		};
		
		Player cricketer = new Player() {
			public void play() {
				System.out.println("Playing cricket");
			}
		};
		cricketer.play();
		
		Player guitarist = new Player() {
			public void play() {
				System.out.println("Playing the guitar");
			}
		};
		guitarist.play();
		
		Player poker = new Player() {
			public void play() {
				System.out.println("Playing poker");
			}
		};
		poker.play();
		
		// Lambda expression (introduced in Java 1.8)
		Player pianist = () -> System.out.println("Playing the piano");
		pianist.play();
		System.out.println(pianist.getClass().getName());
		
		Learner learner = new Learner() {
			public void readBook() {
				System.out.println("Reading books");
			}

			public void watchOnlineVideos() {
				System.out.println("Watching vidoes");
			}
		};
		learner.readBook();
		learner.watchOnlineVideos();
	}

}

//Lambda expressions cannot be used for this interface
interface Learner {
	void readBook();
	void watchOnlineVideos();
}

interface Player {
	void play();
}

//class Cricketer implements Player {
//	public void play() {}
//}
//
//class Guitarist implements Player {
//	public void play() {}
//}


interface Greetings {
	void hello(String name);
}

class GreetingsImpl implements Greetings {
	public void hello(String name) {
		System.out.println("Hello " + name);
	}
}