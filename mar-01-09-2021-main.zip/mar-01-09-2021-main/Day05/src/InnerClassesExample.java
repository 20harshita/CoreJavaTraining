public class InnerClassesExample {

	public static void main(String[] args) {
		Outer outerObj = new Outer();
		
		// Inner class objects are created using Outer class object
		Outer.Inner innerObj = outerObj.new Inner();
		
		TV sony = new TV();
		sony.increaseVolume();
		sony.decreaseVolume();

		TV micromax = new TV();
		TV.Remote remote = micromax.new Remote();
		remote.max();
		remote.min();
		
	}

}

//class Remote {
//	
//	private TV tv;
//	
//	public void max() {
//		tv.volume = 100;
//	}
//	public void min() {
//		tv.volume = 0;
//	}
//	
//}

class A {
	
	class B {
		
		class C {
			
		}
		
	}
	
}
class TV {
	private int volume;
	
	public void increaseVolume() {
		volume++;
	}
	public void decreaseVolume() {
		volume--;
	}
	
	class Remote {
		public void max() {
			volume = 100;
		}
		public void min() {
			volume = 0;
		}
	}
	
}


class Outer {
	class Inner {
		
	}
}