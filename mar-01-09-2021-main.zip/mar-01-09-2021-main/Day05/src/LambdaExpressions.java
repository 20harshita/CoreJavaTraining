
public class LambdaExpressions {

	public static void main(String[] args) {
		Worker worker = () -> System.out.println("Working");
		worker.work();
		
		Worker hardworker = () -> {
			System.out.println("Working"); 
		};
		hardworker.work();
		
		Echo echo = name -> System.out.println(name);
		echo.repeat("Sam");
		
		Adder adder = (a, b) -> a + b;
		System.out.println(adder.sum(12, 34));
		
		Adder adder2 = (a, b) -> {
			System.out.println("a: " + a);
			System.out.println("b: " + b);
			return a + b;
		};
		
		Adder oldStyle = new AdderImpl();
		oldStyle.sum(12, 12);
		
		Adder modernStyle = (a, b) -> a + b;
		modernStyle.sum(12, 13);
		
		
		Operation add = (a, b) -> a + b;
		Operation subtract = (a, b) -> a - b;
		Operation multiply = (a, b) -> a * b;
		Operation divide = (a, b) -> a / b;
		Operation aPlusBWholeSquared = (a, b) -> (a*a) + (b*b) + (2*a*b);
		
		add.compute(12, 20);
		subtract.compute(12, 20);
		multiply.compute(12, 20);
		add.compute(12, 20);
		divide.compute(12, 2);
		aPlusBWholeSquared.compute(12, 20);
		
	}

}

interface Operation {
	int compute(int a, int b);
}


class AdderImpl implements Adder {
	public int sum(int a, int b) {
		return a + b;
	}
}

interface Adder {
	int sum(int a, int b);
	//int square(int a);
} 

interface Echo {
	void repeat(String name);
}

interface Worker {
	void work();
}
