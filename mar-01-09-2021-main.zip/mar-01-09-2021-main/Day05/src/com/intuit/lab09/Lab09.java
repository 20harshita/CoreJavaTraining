package com.intuit.lab09;

public class Lab09 {

	static String word = "hello";
	public static void main(String[] args) {
		
		Cipher simple = new SimpleCipher();
		playWith(simple);
		
		Cipher complex = new ComplexCipher();
		playWith(complex);

	}
	
	static void playWith(Cipher cipher) {
		String encryptedWord = cipher.encrypt(word);
		System.out.println("Encrypted word: " + encryptedWord);
		System.out.println("Decrypted word: " + cipher.decrypt(encryptedWord));
	}

}
