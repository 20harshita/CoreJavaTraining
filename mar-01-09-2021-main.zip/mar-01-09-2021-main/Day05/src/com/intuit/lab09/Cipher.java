package com.intuit.lab09;

public interface Cipher {
	String encrypt(String word);
	String decrypt(String word);
}
