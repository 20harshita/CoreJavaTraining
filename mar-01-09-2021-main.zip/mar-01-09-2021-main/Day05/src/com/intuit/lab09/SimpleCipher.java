package com.intuit.lab09;

public class SimpleCipher implements Cipher {

	public String encrypt(String word) {		
		String letters[] = word.split("");
		StringBuilder builder = new StringBuilder("");
		for (String letter : letters) {
			char ch = letter.charAt(0);
			if(ch == 'z') {
				ch = 'a';
			} else {
				ch++;	
			}
			builder.append(ch);
		}
		return builder.toString();
	}

	public String decrypt(String word) {
		String letters[] = word.split("");
		StringBuilder builder = new StringBuilder("");
		for (String letter : letters) {
			char ch = letter.charAt(0);
			if(ch == 'a') {
				ch = 'z';
			} else {
				ch--;	
			}
			builder.append(ch);
		}
		return builder.toString();
	}

}
