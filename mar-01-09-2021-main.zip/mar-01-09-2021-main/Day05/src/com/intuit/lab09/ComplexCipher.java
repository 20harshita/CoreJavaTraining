package com.intuit.lab09;

import java.util.HashMap;
import java.util.Map;

public class ComplexCipher implements Cipher {

	private Map<String, String> store = new HashMap<>();
	
	public String encrypt(String word) {
		String[] letters = word.split("");
		StringBuilder builder = new StringBuilder("");
		while(builder.length() != word.length()) {
			int randomIndex = (int)(Math.random() * letters.length);
			if(letters[randomIndex] != null) {
				builder.append(letters[randomIndex]);
				letters[randomIndex] = null;	
			}
		}
		store.put(builder.toString(), word);
		return builder.toString();
	}

	public String decrypt(String decryptedWord) {
		return store.get(decryptedWord);
	}

}
