package com.intuit.training;

public class EmployeeUser {
	public static void main(String[] args) {
		Manager m = new Manager();
		System.out.println(m.name + ", " + m.salary);
	}
}
