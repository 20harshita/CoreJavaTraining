package com.intuit.training;

public class Person {
	public String name;
	int age; // package-friendly
}
