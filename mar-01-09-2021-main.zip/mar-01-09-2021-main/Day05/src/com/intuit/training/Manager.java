package com.intuit.training;

public class Manager extends Employee {

	public void printInfo() {
		System.out.println(name + ", " + salary);
	}
}
