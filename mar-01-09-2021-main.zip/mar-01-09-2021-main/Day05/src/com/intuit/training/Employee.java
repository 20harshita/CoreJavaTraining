package com.intuit.training;

public class Employee {
	public String name;
	
	//package-friendly + derived members of other packages
	protected long salary; 
}

//L-to-R
//private, package-friendly, protected, public

//Lombok