package com.intuit.training;

public class MessageConstants {
	public static String header = "Welcome";
	public static String footer = "Copyrights reserved";
	public static String logo = "Intuit";
}
