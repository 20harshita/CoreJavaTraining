package com.intuit.training;

public class FamilyUser {
	
	public static String header = "Family Welcome";

	public static void main(String[] args) {
		Person person = new Person();
		System.out.println(person.name);
		System.out.println(person.age);
	}

}
