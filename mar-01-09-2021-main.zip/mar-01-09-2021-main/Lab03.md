* Create Lab03.java with a main
* You have String input like this

``` java
String input1 = "+5 -1 +9 +5 -7 +5 -3 +2 -4 +6 +8"
```

* Compute the value by parsing input1 
* Visit https://docs.oracle.com/javase/9/docs/api/java/lang/String.html	and read about the __split__, __charAt__, __trim__ methods and use them
* Use __Integer.parseInt()__ to parse a string to int


* Have another input variable like this

``` java
String input2 = "p5 m1 p9 p5 m7 p5 m3 p2 m4 p6 p8"
```

* Compute the value by parsing input2 
* Split the application into smaller methods and implement
