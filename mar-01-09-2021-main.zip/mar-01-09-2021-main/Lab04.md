* Let's refactor the guessing game lab(Lab01).
* Create a __GuessingGame__ class that has the properties and the logic
* Create a __GameUser__ with a main and use the GuessingGame class

* __Note__: GuessingGame class should not have code related to the __UI(read input, display output etc)__. It should be reusable from any UI, be it web-based or even mobile-based 