* __Person__ has name and a collection of cars
* __Car__ has model and color
* Every car has an __Engine__
* __Engine__ has a power

* __Person__ has another Person as a friend
* Define the classes each in a __separate file__.
* Create __Lab05.java__ with a main method. Create the objects with the following data using the classes you have defined.

```
Sam
Bmw, black (2000 CC)
Santro, yellow (1000 CC)
Sam's friend is Ram

Ram has no cars
Ram's friend is Sam
```

